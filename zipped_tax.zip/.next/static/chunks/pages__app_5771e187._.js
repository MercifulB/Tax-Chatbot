(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__3a40d6d2._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_beb00741._.js",
    "static/chunks/[root of the server]__49fd8634._.js"
  ],
  "source": "entry"
});
