(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[root of the server]__a530cb43._.js", {

"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[externals]/node:buffer [external] (node:buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}}),
"[project]/app/api/chat/route.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST),
    "runtime": (()=>runtime)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$openai$2f$dist$2f$index$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/openai/dist/index.mjs [app-edge-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/dist/index.mjs [app-edge-route] (ecmascript) <locals>");
;
;
const runtime = 'edge';
async function POST(req) {
    const { messages } = await req.json();
    const systemPrompt = `
  You are CoTax AI, a helpful US tax assistant.
  
  Whenever appropriate, respond with both a written explanation and a [chart]{...}[/chart] block.
  
  Valid chart types include:
  - bar
  - pie
  - line
  
  Format the chart block like this:
  [chart]
  {
    "type": "bar",
    "data": [
      { "label": "Category A", "value": 100 },
      { "label": "Category B", "value": 200 }
    ]
  }
  [/chart]
  
  You can also use standard Markdown tables when asked. Format them using GitHub Flavored Markdown (GFM):
  
  | Category      | Value |
  |---------------|-------|
  | Income        | 50000 |
  | Deductions    | 12000 |
  | Taxable Income| 38000 |
  
  - Do **not** include the chart block unless the user asks for a graph or chart.
  - Do **not** include tables unless the user asks for a table.
  - Only include **one chart or one table** per response.
  - Make sure your JSON is valid inside [chart]{...}[/chart].
  
  Always keep your responses helpful, simple, and visually clear.
  `;
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["streamText"])({
        model: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$openai$2f$dist$2f$index$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["openai"])('gpt-4o'),
        messages: [
            {
                role: 'system',
                content: systemPrompt
            },
            ...messages
        ]
    });
    return new Response(result.textStream, {
        headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'no-cache',
            Connection: 'keep-alive',
            'Transfer-Encoding': 'chunked'
        }
    });
}
}}),
"[project]/.next-internal/server/app/api/chat/route/actions.js [app-edge-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__a530cb43._.js.map