(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_3360dfd1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_3360dfd1._.js",
  "chunks": [
    "static/chunks/node_modules_next_54ab9f89._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_lodash_90f72504._.js",
    "static/chunks/node_modules_recharts_es6_265a4375._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
    "static/chunks/node_modules_@ai-sdk_2665e7c3._.js",
    "static/chunks/node_modules_261dc312._.js",
    "static/chunks/_4c8a40af._.js"
  ],
  "source": "dynamic"
});
